#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , number1("")
    , number2("")
    , state(1)
    , result(0)
    , operand(0)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::numberClickedHandler()
{
    QPushButton *btn = qobject_cast<QPushButton *>(sender());
    QString buttonName = btn->objectName();
    QString digit = buttonName.right(1);

    qDebug() << "Button name:" << buttonName;

    if (state == 1) {
        number1 += digit;
        ui->num1->setText(number1);
    } else {
        number2 += digit;
        ui->num2->setText(number2);
    }

    qDebug() << "number 1 =" << "\"" + number1 + "\"";
    qDebug() << "number 2 =" << "\"" + number2 + "\"";
}

void MainWindow::addSubMulDivClickHandler()
{
    QPushButton *btn = qobject_cast<QPushButton *>(sender());
    QString name = btn->objectName();

    if (name == "add")      operand = 0;
    else if (name == "sub") operand = 1;
    else if (name == "mul") operand = 2;
    else if (name == "div") operand = 3;

    state = 2;
}

void MainWindow::clearAndEnterClickHandler()
{
    QPushButton *btn = qobject_cast<QPushButton *>(sender());
    QString name = btn->objectName();

    if (name == "clear") {
        state = 1;
        number1 = "";
        number2 = "";
        resetLineEdits();
    } else if (name == "enter") {
        if (number1.isEmpty() || number2.isEmpty())
            return;

        float n1 = number1.toFloat();
        float n2 = number2.toFloat();

        switch (operand) {
        case 0: result = n1 + n2; break;
        case 1: result = n1 - n2; break;
        case 2: result = n1 * n2; break;
        case 3:
            if (n2 != 0)
                result = n1 / n2;
            else {
                ui->result->setText("Error: /0");
                return;
            }
            break;
        }

        ui->result->setText(QString::number(result));
    }
}

void MainWindow::resetLineEdits()
{
    ui->num1->clear();
    ui->num2->clear();
    ui->result->clear();
}

void MainWindow::on_N0_clicked() { numberClickedHandler(); }
void MainWindow::on_N1_clicked() { numberClickedHandler(); }
void MainWindow::on_N2_clicked() { numberClickedHandler(); }
void MainWindow::on_N3_clicked() { numberClickedHandler(); }
void MainWindow::on_N4_clicked() { numberClickedHandler(); }
void MainWindow::on_N5_clicked() { numberClickedHandler(); }
void MainWindow::on_N6_clicked() { numberClickedHandler(); }
void MainWindow::on_N7_clicked() { numberClickedHandler(); }
void MainWindow::on_N8_clicked() { numberClickedHandler(); }
void MainWindow::on_N9_clicked() { numberClickedHandler(); }

void MainWindow::on_add_clicked() { addSubMulDivClickHandler(); }
void MainWindow::on_sub_clicked() { addSubMulDivClickHandler(); }
void MainWindow::on_mul_clicked() { addSubMulDivClickHandler(); }
void MainWindow::on_div_clicked() { addSubMulDivClickHandler(); }

void MainWindow::on_clear_clicked() { clearAndEnterClickHandler(); }
void MainWindow::on_enter_clicked() { clearAndEnterClickHandler(); }
